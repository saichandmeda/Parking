<H1 align="center">Automatic Number Plate Detection and Recognition using YOLOv8</H1>
